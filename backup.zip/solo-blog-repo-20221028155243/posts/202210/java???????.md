title: java 的四种引用类型
date: '2022-10-18 16:38:08'
updated: '2022-10-26 21:36:44'
tags: [java]
permalink: /articles/2022/10/18/1666082288442.html
---
![](https://b3logfile.com/bing/20200530.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 概述

> java有四种引用类型
>
> 1. 强引用
> 2. 软引用
> 3. 弱引用
> 4. 虚引用

### 强引用

> 凡是开发人员通过new创建出来的对象，都属于强引用。
>
> 特点：被强引用所引用的对象，不会被jvm垃圾回收。

例：

```java
public class RefrenceDemo {

    public static void main(String[] args) throws Exception{
        // new 一个对象都是属于强引用
        User user = new User();
        // 在对象还存在引用的时候，jvm gc不会回收该对象
        System.gc();
        System.out.println(user);
        // 把这个引用指向null,那么这个对象的引用就没有了，此时jvm gc就会回收该对象，并触发该类的finalize方法
        user = null;
        System.gc();
        // 防止程序结束，未能通过gc触发类的finalize方法
        System.in.read();
    }
}

class User{
    @Override
    protected void finalize() throws Throwable {
        System.out.println("对象被回收了");
    }
}
```

执行结果：

```bash
com.ccb.p1web.test.User@330bedb4
对象被回收了

Process finished with exit code 0
```

代码解释：

* 当创建一个对象的时候，就建立了一个强引用
* 如果此时发生GC,该对象是不会被回收的，所以控制台还能打印出该对象的hash值
* 如果把该对象的引用指向null,那么这个对象就没有了一个引用指向它，此时发生GC就会把他回收掉。
* 由于这个类实现了finalize方法，JVM在类的加载过程中会标记该类是否为finalize类。回收掉这个对象后，jvm会为它创建一个监听`Finalizer`,这个`java.lang.ref.Finalizer`里面有一个引用队列。当垃圾回收器需要回收该对象时，会把该对象放到引用队列中,这样`java.lang.ref.Finalizer`类就可以从队列中取出该对象，执行对象的finalize方法，并清除和该对象的引用关系。

### 软引用

> 软引用是由`java.lang.ref.SoftReference`所提供的功能，
>
> 特点：被其所关联的对象不存在强引用并且此时JVM内存不足才会去回收该对象

例：

```java
import java.lang.ref.SoftReference;

/**
 * @author zouhuaqiang
 * @Description 引用类型
 * @date 2022/10/25
 */
public class SoftRefrenceDemo {

    public static void main(String[] args) throws Exception{
        // 创建一个软引用并打印对象
        SoftReference<byte[]> softReference = new SoftReference<>(new byte[1024*1024*10]);
        System.out.println("GC前："+softReference.get());
        // 调用GC再打印对象
        System.gc();
        Thread.sleep(500);
        System.out.println("第一次GC后："+softReference.get());
        // 新建对象，并打印软引用中的对象
        byte[] bytes = new byte[1024 * 1024 * 10];
        System.out.println("内存不足后："+softReference.get());
    }
}
```

> *注：在执行这段代码前需要将jvm最大内存设置为20M`-Xmx20M`*
>
> ![image.png](https://b3logfile.com/file/2022/10/image-NqNA5aZ.png)

执行结果：

```bash
GC前：[B@330bedb4
第一次GC后：[B@330bedb4
内存不足后：null

Process finished with exit code 1
```

代码解释：

* 首先创建了一个10m大小的弱引用字节数组对象，直接打印数组没问题
* 调用gc,再获取字节数组，这个时候也是可以取出来的
* 当再次创建一个10m大小的数组，由于在启动前设置了20m的最大内存限制，再加上运行是其它也会占用一下内存，导致没有更多空间存放这个新的数组，此时jvm就会自动清理掉软引用的对象。所以这时候取出来的字节数组就是null了

### 弱引用

> 弱引用是java.lang.ref包下的WeakReferenc类所提供的包装功能
>
> 若一个对象只有一个弱引用，不论内存是否够用，在gc后就会被回收掉

例：

```java
import java.lang.ref.WeakReference;

/**
 * @author zouhuaqiang
 * @Description 引用类型
 * @date 2022/10/25
 */
public class RefrenceDemo {

    public static void main(String[] args) throws Exception{
        // 创建一个弱引用
        WeakReference<User> user = new WeakReference<>(new User());
        System.out.println("GC前："+user.get());
        // 手动gc
        System.gc();
        Thread.sleep(500);
        // 打印gc的对象
        System.out.println("GC后："+user.get());
    }
}

class User{

    @Override
    protected void finalize() throws Throwable {
        System.out.println(this+"被回收");
    }
}
```

执行结果：

```bash
GC前：com.ccb.p1web.test.User@330bedb4
com.ccb.p1web.test.User@330bedb4被回收
GC后：null

Process finished with exit code 0
```

代码解释：

* 创建一个弱引用，并打印该对象，没有问题
* 手动调用GC后再次打印，结果为null,并且该类的`finalize`方法被调用
* 说明在GC之后，所有只有弱引用的对象都会被回收掉

### 虚引用

> 虚引用在任何时候都可能被垃圾回收器回收，主要用来跟踪对象被垃圾回收器回收的活动，被回收时会收到⼀个系统通知。虚引用与软引用和弱引用的⼀个区别在于：虚引用必须和引用队列 （ReferenceQueue）联合使用。当垃圾回收器准备回收⼀个对象时，如果发现它还有虚引用，就会在回收对象的内存之前，把这个虚引用加⼊到与之关联的引用队列中。
>
> 在NIO中可以使用堆外的内存，也叫直接内存，直接内存的回收就是使用的虚引用通知机制。
