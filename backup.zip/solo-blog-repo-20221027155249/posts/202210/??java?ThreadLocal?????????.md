title: 什么？java的ThreadLocal可能会产生内存泄露！
date: '2022-10-24 21:51:08'
updated: '2022-10-26 21:31:14'
tags: [java]
permalink: /articles/2022/10/24/1666619468874.html
---
![](https://b3logfile.com/bing/20200520.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 前言

> 可能有点小伙伴看到这个问题还有点懵，`ThreadLocal`是啥，又和内存泄露有什么关系。
>
> 是的，我刚开始也是一脸懵。直到我翻遍各种博客，跟着某校的培训视频看了`ThreadLocal`源码总算是搞明白了。
>
> 接下来我就和大伙儿分享下我的理解，不知道是不是完全正确，还望高人指点指点😄

### 什么是内存泄露？

> 如果垃圾收集器无法移除不再被引用的对象，那么应用程序中就有可能出现内存泄漏。

### 那怎么才会导致内存不会被回收呢？

了解过jvm垃圾回收机制的小伙伴应该知道（不了解的可以去看看这篇文章：[还没写，先欠着]()），当一个对象没有被任何一个引用指向，那么就会被垃圾回收器回收。所以，如果一个对象一直被一个引用指向，那么这个对象就一直不会被回收掉。虽然jvm的垃圾回收器为我们开发人员做了很多事情，让我们java开发人员免去了C语言开发人员的内存回收的烦恼，但是如果我们使用不当，进入到垃圾回收机制的盲区，也会造成内存泄露，使系统随着时间的推移越来越卡顿。所以，~~万能的重启大法也能解决因为内存泄露导致系统卡顿的问题~~，但是老板会生气:huaji:

### 那内存泄露又和ThreadLocal有什么关系呢？

首先讲讲ThreadLocal特点和在开发中的使用场景

> 特点：ThreadLocal用于提供线程的局部变量，在多线程环境里，每个线程的局部变量独立于其他线程的局部变量。也就是说 ThreadLocal 可以为每个线程创建一个【单独的变量副本】，每个线程存取的内容都是独立的。

做个小实验：

```java
import java.util.HashMap;
import java.util.Map;

/**
 * @author zouhuaqiang
 * @Description ThreadLocal Demo
 * @date 2022/10/24
 */
public class ThreadLocalDemo {

    // 创建ThreadLocal
    public static final ThreadLocal<Person> threadLocal = new ThreadLocal<>();

    public static void main(String[] args) throws Exception {
        // 新建一个map用作和ThreadLocal对比
        Map<String,Person> map = new HashMap<>(16);
        // 新建一个线程
        Thread thread0 = new Thread(new Runnable() {
            @Override
            public void run() {
                // 往ThreadLocal设置值
                Person person = new Person("张三",18);
                threadLocal.set(person);
                map.put("person",person);
                System.out.println(Thread.currentThread().getName()+"ThreadLocal中person对象:"+threadLocal.get());
                System.out.println(Thread.currentThread().getName()+"Map中person对象:"+map.get("person"));
            }
        });
        thread0.start();
        // 主线程睡眠500毫秒，保证在下一个线程取的时候，值已经塞到threadLocal中
        Thread.sleep(500L);
        // 另起一个线程
        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                // 去除ThreadLocal中的值并打印
                System.out.println(Thread.currentThread().getName()+"ThreadLocal中person对象:"+threadLocal.get());
                System.out.println(Thread.currentThread().getName()+"Map中person对象:"+map.get("person"));
            }
        });
        thread1.start();
    }
}

class Person{
    private String name;

    private int age;

    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}

```

执行结果如下：

```bash
Thread-0ThreadLocal中person对象:Person{name='张三', age=18}
Thread-0Map中person对象:Person{name='张三', age=18}
Thread-1ThreadLocal中person对象:null
Thread-1Map中person对象:Person{name='张三', age=18}
```

可以看到：在thread1中设置的Person对象，在thread2中无法获取到，因为这个对象是线程1独享的。所以在多线程的开发中，可以使用ThreadLocal存储各自线程的对象。比如把用户请求的session放到ThreadLocal中，就不用把HttpSession传递到业务组件的各个方法中，直接通过ThreadLocal就能取出来。

再举一个例子：spring的事务管理器，为什么加了`@Transactional`就能自动在方法结束后提交事务呢，大家都知道，要在同一个事务里肯定要保证使用的同一个数据库连接才行，所以spring用ThreadLocal保存的当前事务使用的数据库连接`Connection`，在每一个和数据库交互的地方都是用ThreadLocal中取出来的同一个连接，而且不会和其他请求过来数据库连接的冲突。

好der，ThreadLocal的特点和应用场景就解释完了。接下来就来通过源码分析，ThreadLocal是怎么做到的线程之间隔离，以及为啥可能会出现内存泄露的问题。

### 源码部分

首先进入到ThreadLocal的set(T value)方法

```java
public void set(T value) {
    // 获取当前线程
    Thread t = Thread.currentThread();
    // 取出当前线程的ThreadLocalMap
    ThreadLocalMap map = getMap(t);
    if (map != null)
	// 如果map存在就将当前ThreadLocal作为map的key存放到map中
        map.set(this, value);
    else
	// 如果不存在map,就先创建一个map，再设置
        createMap(t, value);
}
```

这段代码什么意思呢？

就是在Thread这个类中，维护着一个叫做ThreadLocalMap的类，它的数据结构类似map，已键值对存储对象。

它的key是ThreadLocal,value是Object，所以上面这段代码会用this作为key。

画个草图：*（图很丑，求推荐一个好用的绘图工具）*

![image.png](https://b3logfile.com/file/2022/10/image-yoHWyII.png)

所以，每个线程都有一个自己的ThreadLocalMap,他里面的ThreadLocal保存的对象也是独立的。而且这个ThreadLocalMap理论上可以设置无数个ThreadLocal。

既然知道这个ThreadLocalMap是一个K,V键值对的map，那么当一个存放在ThreadLocalMap中的对象不使用的时候，虽然这个使用这个对象的引用已经没了，但是如果这个线程是线程池里的，那么这个ThreadLocalMap的value还和这个对象有着引用的关系。所以这个对象永远不会被回收，就会使内存占用越来越高，造成**内存泄露**。

其实ThreadLocal早就考虑到了这个问题，给我们提供了一个remove()方法，它的主要目的就是把当前ThreadLocal所对应的键值对删除掉，就能解决这个问题。

```java
// ThreadLocal的remove方法
public void remove() {
     ThreadLocalMap m = getMap(Thread.currentThread());
     if (m != null)
     	m.remove(this);
}
```

那么就有一个问题了：

value可能会内存泄露，那key怎么不会？

接下来继续看源码

```java
// ThreadLocalMap 的set方法
private void set(ThreadLocal<?> key, Object value) {
	// We don't use a fast path as with get() because it is at
	// least as common to use set() to create new entries as
	// it is to replace existing ones, in which case, a fast
	// path would fail more often than not.

	Entry[] tab = table;
	int len = tab.length;
	int i = key.threadLocalHashCode & (len-1);

	for (Entry e = tab[i];
		 e != null;
		 e = tab[i = nextIndex(i, len)]) {
		ThreadLocal<?> k = e.get();

		if (k == key) {
			e.value = value;
			return;
		}

		if (k == null) {
			replaceStaleEntry(key, value, i);
			return;
		}
	}

	tab[i] = new Entry(key, value);
	int sz = ++size;
	if (!cleanSomeSlots(i, sz) && sz >= threshold)
		rehash();
}
```

这个方法里能看到ThreadLocalMap里的键值对其实是一个Entry，对Map做过遍历的应该知道，Map的键值对也是Entry，但是这里的Entry不太一样。

```java
static class Entry extends WeakReference<ThreadLocal<?>> {
	/** The value associated with this ThreadLocal. */
	Object value;

	Entry(ThreadLocal<?> k, Object v) {
		// 调用父类的方法使key建立弱引用
		super(k);
		value = v;
	}
}
```

可以看到，这个Entry继承了一个叫做WeakReference的类。这个类是什么呢？其实它就是java四种引用类型中的`弱引用`（感兴趣的可以去看看[java 的四种引用类型](https://www.zouhuaqiang.top/articles/2022/10/18/1666082288442.html)）。它的特点就是在jvm垃圾回收的时候只有弱引用的对象，都会被回收。所以此时当一个任务执行完成之后，可以将ThreadLocal设置成为null，局部变量的强引用就会失效，存在Map中的Entry只有key是弱引用，如果不进行清理的话，则会出现内存泄漏的问题，此时出现垃圾回收的时候就会回收掉ThreadLocal对象，也就是说ThreadLocal是尽量的去避免内存泄漏的问题。但是解决不了根本的问题，所以需要开发人员手动去调用remove()方法才能够彻底解决内存泄漏的问题。

这就是我对ThreadLocal内存可能泄露的理解，有不对的地方，欢迎指出，我们共同进步😁
