title: windows vue 开发环境搭建
date: '2022-10-18 16:18:00'
updated: '2022-10-19 14:14:02'
tags: [node, vue]
permalink: /articles/2022/10/18/1666081115227.html
---
![](https://b3logfile.com/bing/20220518.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 1.安装node

#### 1.1 安装

官网：[Download | Node.js](https://nodejs.org/en/download/ "Download | Node.js")

![image.png](https://b3logfile.com/file/2022/10/image-fDdSrFc.png)

> 选择你的系统对应位数的版本

你也可以选择对应的历史版本：[Previous Releases | Node.js](https://nodejs.org/en/download/releases/ "Previous Releases | Node.js")

> 推荐使用[nvm](https://github.com/coreybutler/nvm-windows/releases)管理node版本

下载完成后，双击运行

点击`next`

![image.png](https://b3logfile.com/file/2022/10/image-agCpzMq.png)

勾选协议，然后点击`next`

![image.png](https://b3logfile.com/file/2022/10/image-RNmJime.png)

选择安装目录（不建议安装到系统盘，系统盘大的随意），点击`next`

![1666093161833.jpg](https://b3logfile.com/file/2022/10/1666093161833-UGxBjdF.jpg)

确认Add to PATH 已勾选，然后`next`

![image.png](https://b3logfile.com/file/2022/10/image-3D2v9XW.png)

点击`next`

![image.png](https://b3logfile.com/file/2022/10/image-1E6Jgwf.png)

点击`Install`,等待完成

![image.png](https://b3logfile.com/file/2022/10/image-SXVAmHG.png)

![image.png](https://b3logfile.com/file/2022/10/image-vlyuSsI.png)

点击`Finish`

![image.png](https://b3logfile.com/file/2022/10/image-6sJwB9E.png)

安装完成后可以打开命令窗口查看版本，检查是否安装成功

`win`+`R`  输入 `cmd` 回车

![image.png](https://b3logfile.com/file/2022/10/image-HPuZpiJ.png)

#### 1.2 设置node缓存目录,和全局安装目录

在安装目录下新建目录`node_cache`和`node_global`

![image.png](https://b3logfile.com/file/2022/10/image-JOuMvZH.png)

设置缓存目录

```bash
npm config set cache "你的node安装目录\node_cache"
```

设置全局安装目录

```bash
npm config set prefix "你的node安装目录\node_global"
```

设置环境变量

鼠标右键点击`我的电脑`,选择属性，然后点击`高级系统设置`,点击`环境变量`

![image.png](https://b3logfile.com/file/2022/10/image-SmKoN4Y.png)

在系统变量里找到`Path`,点击编辑

![image.png](https://b3logfile.com/file/2022/10/image-B3dMSSB.png)

点击`新建`，然后复制上面设置的`全局安装目录:你的node安装目录\node_global`

![image.png](https://b3logfile.com/file/2022/10/image-S4F9PsK.png)

然后一路确定加保存

#### 1.3 安装淘宝镜像加速

```bash
npm install -g cnpm --registry=https://registry.npm.taobao.org
```

命令窗口输入：`cnpm -v` 查看版本验证是否安装成功

![image.png](https://b3logfile.com/file/2022/10/image-5QI8mw0.png)

现在就可以使用 `cnpm` 替代 `npm` 实现镜像加速了

```bash
例：cnpm install
```

或直接修改默认镜像地址，然后直接使用 `npm install`也可以加速

```bash
npm config set registry "https://registry.npm.taobao.org"
```

### 2. 安装vue-cli

#### 2.1 安装

执行命令,等待完成

```bash
cnpm install -g @vue/cli
```

执行命令：`vue -V`(V大写)查看是否安装成功

![image.png](https://b3logfile.com/file/2022/10/image-RqsP513.png)

#### 2.2 创建项目

创建项目有两种方式

1.使用命令

```bash
vue create myproject
```

我这里选择[Vue3]，你可以根据自己需求选择

![image.png](https://b3logfile.com/file/2022/10/image-hz0vJDC.png)

创建完成

![image.png](https://b3logfile.com/file/2022/10/image-4SeIc0N.png)

启动测试

```bash
cd myproject
npm run serve
```

浏览器访问如下地址

![image.png](https://b3logfile.com/file/2022/10/image-R8uxczd.png)

![image.png](https://b3logfile.com/file/2022/10/image-DH1TDAw.png)

按 `ctrl + c` 可终止服务

2.使用可视化工具vue ui

执行命令,稍等一会儿会自动打开一个浏览器窗口

```bash
vue ui
```

![image.png](https://b3logfile.com/file/2022/10/image-yHiPkdG.png)

点击左下角`三个点`，选择`Vue 项目管理器`

选择`创建`，选择好目录之后点击`在此创建新项目`

![image.png](https://b3logfile.com/file/2022/10/image-r8TovxS.png)

输入项目名称，选择 `npm` 包管理器（npm已自带安装，想用其它包管理器的自行选择安装）,然后点击`下一步`

![image.png](https://b3logfile.com/file/2022/10/image-fbk1JRq.png)

选择Vue版本，然后点击`创建项目`等待完成

![image.png](https://b3logfile.com/file/2022/10/image-cCPDRen.png)

创建完成

![image.png](https://b3logfile.com/file/2022/10/image-jcqvFgY.png)

依次点击 `任务->serv->运行`

![image.png](https://b3logfile.com/file/2022/10/image-mRD2PM1.png)

点击启动app

![image.png](https://b3logfile.com/file/2022/10/image-xzpPrbu.png)

![image.png](https://b3logfile.com/file/2022/10/image-UOdi6CC.png)

ok！大功告成！✌

vue开发环境就搭建完成了，里面还有很多知识点，包括vue项目的配置，使用axios与后台交互，使用vue-router路由和vuex全局缓存等等，咱们下期再讲😁 。
