title: 如何替换jar包中的class
date: '2022-10-19 19:56:11'
updated: '2022-10-19 20:00:12'
tags: [java]
permalink: /articles/2022/10/19/1666180571722.html
---
![](https://b3logfile.com/bing/20210329.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### 为什么要替换？

> 因为有时候代码只是出现了一点点小问题，优化了几句代码。如果把整个工程都更新一遍，可能对已有的业务代码产生未知的影响。

#### 1.在jar包所在目录，点击鼠标右键选择 `Git Bash Here`

![image.png](https://b3logfile.com/file/2022/10/image-48Un2jR.png)

#### 2.先查询class所在jar包路径

```bash
 jar -tvf ruoyi-admin.jar | grep ruoyi-system-3.8.3.jar
```

![image.png](https://b3logfile.com/file/2022/10/image-Q3wHciR.png)

#### 3.使用该路径提取jar包

```bash
jar -xvf ruoyi-admin.jar BOOT-INF/lib/ruoyi-system-3.8.3.jar
```

会生成一个对应的目录

![image.png](https://b3logfile.com/file/2022/10/image-W0YTa4J.png)

进入到该目录下

```bash
 cd BOOT-INF/lib/
```

#### 4.查询目标class文件的地址

```bash
jar -tvf ruoyi-system-3.8.3.jar | grep SysLogininforServiceImpl.class
```

![image.png](https://b3logfile.com/file/2022/10/image-iqrs8Yr.png)

得到一个该class文件的地址

#### 5.获取该class

```bash
jar -xvf ruoyi-system-3.8.3.jar com/ruoyi/system/service/impl/SysLogininforServiceImpl.class
```

会产生一个对应的目录

![image.png](https://b3logfile.com/file/2022/10/image-yCEdwGV.png)

然后就是手动替换掉里面的class文件

#### 5.将新的class复制到jar包里

```bash
jar -uvf0 ruoyi-system-3.8.3.jar com/ruoyi/system/service/impl/SysLogininforServiceImpl.class
```

![image.png](https://b3logfile.com/file/2022/10/image-NJDMPsg.png)

再回到最外层目录

```bash
cd ../../
```

#### 6.将修改过的jar包复制到最外层jar包中

```bash
jar -uvf0 ruoyi-admin.jar BOOT-INF/lib/ruoyi-system-3.8.3.jar
```

![image.png](https://b3logfile.com/file/2022/10/image-QUpMsV8.png)

Ok，到此结束，充分测试后就交给运维大佬部署吧:huaji:
